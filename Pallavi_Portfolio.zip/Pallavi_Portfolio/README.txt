PALLAVI PORTFOLIO WEBSITE

1. Extract this ZIP folder.
2. Open the Pallavi_Portfolio folder.
3. Double-click index.html to open the website in your browser.
4. To edit the website, open index.html in VS Code or Notepad.
